## TiledMapTest
### TiledMap测试的例子(Cocos Creator 1.6.1版本)
参考：http://blog.csdn.net/potato47/article/details/51366481

简单使用上下左右键盘操作机器人player吃掉星星star，使用障碍物barriers来阻挡player的道路。

截图：
<img src='/QQ20171001-213412%402x-tiledMap.png' width='400' height='400'/>

